package Bar::Baz::Bad;
use strict;
use warnings;

our $VERSION = 0.01;

1;
