package Foo::Two;
use strict;
use warnings;

our $VERSION = 0.02;

1;
