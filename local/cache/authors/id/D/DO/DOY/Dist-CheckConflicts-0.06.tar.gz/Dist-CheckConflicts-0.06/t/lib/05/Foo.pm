package Foo;

sub foo { }

1;
